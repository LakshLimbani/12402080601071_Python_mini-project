# Typing Speed Tester

A beginner-friendly Python project that measures typing speed and character accuracy using a simple graphical interface.

## Concepts covered
- **Strings:** displayed sentences and the text entered by the user.
- **Functions and methods:** separate functions handle starting the timer, calculating accuracy, finishing the test, and resetting the test.
- **GUI:** Tkinter labels, buttons, a text area, and status/result messages.
- **Basic logic:** loops, conditions, random sentence selection, and elapsed-time calculations.

## Requirements
- Python 3.8 or newer
- Tkinter (included with most standard Python installations)

No third-party packages are required.

## How to run
1. Extract the ZIP file.
2. Open a terminal or command prompt in the project folder.
3. Run:

   ```bash
   python main.py
   ```

## How to use
1. Read the sentence shown in the box.
2. Start typing it in the text area. The timer starts with your first key press.
3. Click **Finish Test** to see words per minute (WPM), accuracy, and elapsed time.
4. Click **New Text** to try another sentence.

## Notes
- WPM is calculated as the number of words typed divided by elapsed minutes.
- Accuracy compares each typed character with the target sentence at the same position. Extra characters count as incorrect.
