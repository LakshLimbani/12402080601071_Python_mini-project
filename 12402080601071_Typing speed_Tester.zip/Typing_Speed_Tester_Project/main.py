import tkinter as tk
from tkinter import messagebox
import random
import time


SENTENCES = [
    "Python makes it easy to build useful applications.",
    "Practice every day to improve your typing speed.",
    "A quick brown fox jumps over the lazy dog.",
    "Small steps taken consistently lead to big results.",
    "Programming is problem solving with clear instructions.",
    "Focus on accuracy first and speed will follow.",
    "Learning new skills becomes easier with regular practice.",
    "Simple projects are a great way to learn Python."
]


class TypingSpeedTester:
    """A small GUI app that measures typing speed and accuracy."""

    def __init__(self, root):
        self.root = root
        self.root.title("Typing Speed Tester")
        self.root.geometry("760x520")
        self.root.minsize(620, 450)
        self.root.configure(bg="#f2f5f9")

        self.start_time = None
        self.test_running = False
        self.target_text = ""

        self.title_label = tk.Label(
            root, text="Typing Speed Tester",
            font=("Arial", 24, "bold"), bg="#f2f5f9", fg="#20304a"
        )
        self.title_label.pack(pady=(22, 5))

        self.subtitle_label = tk.Label(
            root, text="Test your typing speed and accuracy",
            font=("Arial", 11), bg="#f2f5f9", fg="#53627a"
        )
        self.subtitle_label.pack(pady=(0, 18))

        self.prompt_box = tk.Label(
            root, text="", wraplength=660, justify="left",
            font=("Arial", 14), bg="white", fg="#26344d",
            padx=18, pady=18, relief="groove", bd=1
        )
        self.prompt_box.pack(fill="x", padx=32, pady=(0, 15))

        self.input_box = tk.Text(
            root, height=5, wrap="word", font=("Arial", 12),
            padx=10, pady=10, undo=True
        )
        self.input_box.pack(fill="x", padx=32)
        self.input_box.bind("<KeyPress>", self.start_timer)

        button_frame = tk.Frame(root, bg="#f2f5f9")
        button_frame.pack(pady=16)

        self.check_button = tk.Button(
            button_frame, text="Finish Test", command=self.finish_test,
            font=("Arial", 11, "bold"), bg="#2563eb", fg="white",
            activebackground="#1d4ed8", activeforeground="white",
            padx=18, pady=8, relief="flat", cursor="hand2"
        )
        self.check_button.grid(row=0, column=0, padx=6)

        self.reset_button = tk.Button(
            button_frame, text="New Text", command=self.new_test,
            font=("Arial", 11), bg="#e2e8f0", fg="#20304a",
            padx=18, pady=8, relief="flat", cursor="hand2"
        )
        self.reset_button.grid(row=0, column=1, padx=6)

        self.result_label = tk.Label(
            root, text="WPM: —     Accuracy: —     Time: —",
            font=("Arial", 12, "bold"), bg="#f2f5f9", fg="#20304a"
        )
        self.result_label.pack(pady=(2, 10))

        self.status_label = tk.Label(
            root, text="Click the typing area and start typing.",
            font=("Arial", 10), bg="#f2f5f9", fg="#53627a"
        )
        self.status_label.pack()

        self.new_test()

    def new_test(self):
        """Choose a new sentence and reset the test."""
        self.target_text = random.choice(SENTENCES)
        self.prompt_box.config(text=self.target_text)
        self.input_box.config(state="normal")
        self.input_box.delete("1.0", tk.END)
        self.start_time = None
        self.test_running = False
        self.result_label.config(text="WPM: —     Accuracy: —     Time: —")
        self.status_label.config(text="Click the typing area and start typing.")
        self.input_box.focus_set()

    def start_timer(self, event=None):
        """Start the timer on the first key press."""
        if not self.test_running:
            self.start_time = time.time()
            self.test_running = True
            self.status_label.config(text="Timer started — keep typing!")

    def calculate_accuracy(self, typed_text):
        """Return the percentage of characters typed correctly by position."""
        if not typed_text:
            return 0.0

        correct = 0
        for index, character in enumerate(typed_text):
            if index < len(self.target_text) and character == self.target_text[index]:
                correct += 1

        return (correct / len(typed_text)) * 100

    def finish_test(self):
        """Calculate words per minute, accuracy, and elapsed time."""
        typed_text = self.input_box.get("1.0", "end-1c")

        if not typed_text.strip():
            messagebox.showinfo("No text entered", "Type the displayed sentence first.")
            return

        if self.start_time is None:
            self.start_time = time.time()

        elapsed_seconds = max(time.time() - self.start_time, 1)
        elapsed_minutes = elapsed_seconds / 60
        words_typed = len(typed_text.split())
        wpm = words_typed / elapsed_minutes
        accuracy = self.calculate_accuracy(typed_text)

        self.result_label.config(
            text=f"WPM: {wpm:.1f}     Accuracy: {accuracy:.1f}%     Time: {elapsed_seconds:.1f}s"
        )
        self.status_label.config(text="Test complete. Select New Text to try again.")
        self.test_running = False

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    app_root = tk.Tk()
    app = TypingSpeedTester(app_root)
    app.run()
